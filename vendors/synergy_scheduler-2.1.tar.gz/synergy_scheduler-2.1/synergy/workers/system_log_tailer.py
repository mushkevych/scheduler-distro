import logging
import time
from os.path import isfile
from threading import Lock

import pygtail

from synergy.conf import context
from synergy.db.dao.box_configuration_dao import BoxConfigurationDao, QUERY_PROCESSES_FOR_BOX_ID
from synergy.supervisor.supervisor_configurator import get_box_id
from synergy.system.synergy_process import SynergyProcess
from synergy.system.system_logger import get_log_filename
from system.log_recording_handler import LogRecordingHandler
from synergy.supervisor.supervisor_constants import PROCESS_SUPERVISOR
from synergy.scheduler.scheduler_constants import PROCESS_SCHEDULER, PROCESS_GC, PROCESS_MX


class SystemLogTailer(SynergyProcess):
    def __init__(self, process_name):
        super(SystemLogTailer, self).__init__(process_name)
        self.thread_handlers = dict()
        self.lock = Lock()
        self.box_id = get_box_id(self.logger)
        self.bc_dao = BoxConfigurationDao(self.logger)
        self.logger.info(f'Started {self.process_name} with configuration for BOX_ID={self.box_id}')

        # format: {proccess_name: tailer}
        self.tailers = dict()

        # format: {process_name: box_configuration.db_id}
        self.db_ids = dict()

    def setup(self):

        try:
            box_config = self.bc_dao.get_one([self.box_id, process_name])
            if not box_config.db_id:
                return
        except LookupError as e:
            # given process is not running on this machine
            pass
        except Exception as e:
            pass

        box_configurations = self.bc_dao.run_query(QUERY_PROCESSES_FOR_BOX_ID(self.box_id))
        for box_config in box_configurations:
            self.db_ids[box_config.process_name] = box_config.db_id

        for process_name in context.process_context:
            fqfn = get_log_filename(process_name)
            if not isfile(fqfn) \
                    or process_name in self.tailers\
                    or process_name not in self.db_ids:
                continue

            self.tailers[process_name] = pygtail.Pygtail(fqfn, copytruncate=False)

    def tail_logs(self):
        for process_name in self.tailers:
            tailer = self.tailers[process_name]
            db_id = self.db_ids[process_name]

            for line in tailer.readlines():
                adhock_logger = logging.getLogger('System Log Tailing')
                adhock_logger.handlers = []
                log_recording_handler = LogRecordingHandler(adhock_logger, db_id)
                try:
                    log_recording_handler.attach()
                    adhock_logger.info(line)
                except Exception as e:
                    self.logger.error(f'Exception while recording entries from {tailer.filename} due to {e}')
                finally:
                    log_recording_handler.detach()

    def run(self):
        while True:
            self.setup()
            self.tail_logs()
            time.sleep(10.0)


if __name__ == '__main__':
    streamer = SystemLogTailer()
    streamer.setup()
    streamer.run()
