PROCESS_BASH_DRIVER = 'BashDriver'

TOKEN_BASH_DRIVER = 'bash'

# common arguments for remote command execution
ARGUMENT_CMD_PATH = 'cmd_path'
ARGUMENT_CMD_FILE = 'cmd_file'
ARGUMENT_CMD_ARGS = 'cmd_args'
ARGUMENT_CMD_HOST = 'cmd_host'
